package com.yakintalk.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity implements NearbyController.Listener {
    private static final int PERMISSION_REQUEST = 40;
    private static final int BG = Color.rgb(246, 247, 251);
    private static final int SURFACE = Color.WHITE;
    private static final int TEXT = Color.rgb(25, 29, 38);
    private static final int MUTED = Color.rgb(116, 123, 138);
    private static final int BORDER = Color.rgb(228, 232, 240);
    private static final int ACCENT = Color.rgb(91, 92, 226);
    private static final int ACCENT_DARK = Color.rgb(67, 67, 202);
    private static final int ACCENT_SOFT = Color.rgb(239, 239, 255);
    private static final int GREEN = Color.rgb(35, 162, 109);
    private static final int GREEN_SOFT = Color.rgb(232, 248, 240);
    private static final int RED = Color.rgb(225, 74, 86);
    private static final int DARK = Color.rgb(20, 23, 36);

    private LinearLayout root;
    private IletRuntime nearby;
    private AudioCallManager audio;
    private RingbackPlayer ringback;
    private List<Peer> peers = new ArrayList<>();
    private final Map<String, List<String>> chats = new HashMap<>();
    private String status = "Hazırlanıyor";
    private String chatEndpoint;
    private String callEndpoint;
    private boolean callActive;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(SURFACE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); setContentView(root);
        nearby = IletRuntime.get(this);
        audio = new AudioCallManager(this);
        ringback = new RingbackPlayer();
        requestPermissionsIfNeeded();
        renderHome();
    }

    @Override protected void onStart() { super.onStart(); nearby.attachUi(this); }
    @Override protected void onResume() { super.onResume(); if (hasNearbyPermissions()) IletService.start(this); }
    @Override protected void onStop() { nearby.detachUi(this); super.onStop(); }
    @Override protected void onDestroy() { ringback.stop(); audio.stop(); super.onDestroy(); }

    @Override public void onBackPressed() {
        if (callEndpoint != null) { stopCall(true); return; }
        if (chatEndpoint != null) { chatEndpoint = null; renderHome(); return; }
        super.onBackPressed();
    }

    private void requestPermissionsIfNeeded() {
        List<String> wanted = new ArrayList<>();
        wanted.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33) { wanted.add(Manifest.permission.POST_NOTIFICATIONS); wanted.add(Manifest.permission.NEARBY_WIFI_DEVICES); }
        if (Build.VERSION.SDK_INT >= 31) {
            wanted.add(Manifest.permission.BLUETOOTH_SCAN); wanted.add(Manifest.permission.BLUETOOTH_CONNECT); wanted.add(Manifest.permission.BLUETOOTH_ADVERTISE);
        }
        if (Build.VERSION.SDK_INT >= 29 && Build.VERSION.SDK_INT <= 31) wanted.add(Manifest.permission.ACCESS_FINE_LOCATION);
        else if (Build.VERSION.SDK_INT <= 28) wanted.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        List<String> missing = new ArrayList<>();
        for (String p : wanted) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), PERMISSION_REQUEST);
    }

    private boolean hasNearbyPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) return false;
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) return false;
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return false;
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) return false;
        }
        if (Build.VERSION.SDK_INT >= 29 && Build.VERSION.SDK_INT <= 31 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return false;
        return Build.VERSION.SDK_INT > 28 || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code != PERMISSION_REQUEST) return;
        if (hasNearbyPermissions()) { status = "Yakındaki kullanıcılar aranıyor"; IletService.start(this); }
        else status = "Yakındaki cihaz izni gerekli";
        renderCurrent();
    }

    private void renderCurrent() { if (callEndpoint != null) renderCall(); else if (chatEndpoint != null) renderChat(chatEndpoint); else renderHome(); }
    private void prepareLightScreen() {
        root.setGravity(Gravity.NO_GRAVITY); root.setBackgroundColor(BG);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(SURFACE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); root.removeAllViews();
    }

    private void renderHome() {
        chatEndpoint = null; prepareLightScreen();
        LinearLayout header = row(); header.setPadding(dp(20), dp(18), dp(18), dp(10));
        LinearLayout titleBlock = new LinearLayout(this); titleBlock.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("İLET", 28, TEXT, true); title.setLetterSpacing(-0.02f);
        TextView subtitle = text("Yakındaki kişilerle doğrudan iletişim", 13, MUTED, false); subtitle.setPadding(0, dp(3), 0, 0);
        titleBlock.addView(title); titleBlock.addView(subtitle); header.addView(titleBlock, new LinearLayout.LayoutParams(0, -2, 1));
        Button profile = pillButton(initials(nearby.getDisplayName())); profile.setOnClickListener(v -> editName());
        header.addView(profile, new LinearLayout.LayoutParams(dp(48), dp(48))); root.addView(header);

        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(dp(18), dp(17), dp(18), dp(17)); hero.setBackground(gradientCard()); hero.setElevation(dp(2));
        LinearLayout heroTop = row(); heroTop.addView(text("●",15,Color.rgb(182,255,217),true));
        TextView heroStatus = text(status,13,Color.WHITE,true); heroStatus.setPadding(dp(8),0,0,0); heroTop.addView(heroStatus,new LinearLayout.LayoutParams(0,-2,1));
        TextView count=text(peers.size()+" yakında",12,Color.WHITE,true); count.setGravity(Gravity.CENTER); count.setBackground(round(Color.argb(42,255,255,255),30)); heroTop.addView(count,new LinearLayout.LayoutParams(dp(82),dp(32))); hero.addView(heroTop);
        TextView heroTitle=text("Bağlantı ayarı yok.",22,Color.WHITE,true); heroTitle.setPadding(0,dp(14),0,dp(3)); hero.addView(heroTitle);
        TextView heroText=text("İLET arka planda çalışırken de yakındaki kişiler otomatik bulunur. Mesaj veya arama için dokunmanız yeterli.",13,Color.rgb(226,227,255),false); heroText.setLineSpacing(0,1.12f); hero.addView(heroText);
        LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2); hlp.setMargins(dp(18),dp(6),dp(18),dp(18)); root.addView(hero,hlp);

        LinearLayout section=row(); section.setPadding(dp(20),0,dp(20),dp(8)); section.addView(text("YAKINDAKİLER",12,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView live=text(peers.isEmpty()?"Aranıyor":"Canlı",12,peers.isEmpty()?MUTED:GREEN,true); live.setBackground(round(peers.isEmpty()?Color.rgb(238,240,244):GREEN_SOFT,30)); live.setGravity(Gravity.CENTER); section.addView(live,new LinearLayout.LayoutParams(dp(68),dp(28))); root.addView(section);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(18),0,dp(18),dp(26)); scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(peers.isEmpty()) {
            LinearLayout empty=new LinearLayout(this); empty.setOrientation(LinearLayout.VERTICAL); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(24),dp(30),dp(24),dp(30)); empty.setBackground(strokedRound(SURFACE,BORDER,20));
            TextView ic=text("⌁",36,ACCENT,true); ic.setGravity(Gravity.CENTER); empty.addView(ic);
            TextView et=text("Henüz kimse görünmüyor",17,TEXT,true); et.setPadding(0,dp(10),0,dp(6)); empty.addView(et);
            TextView eb=text("Diğer telefonda İLET'i açın. Eşleştirme veya Wi‑Fi ağı seçmeniz gerekmez.",13,MUTED,false); eb.setGravity(Gravity.CENTER); empty.addView(eb); list.addView(empty,spaced(8));
        } else for(Peer p:peers) list.addView(peerCard(p),spaced(7));
        TextView footer=text("İNTERNET YOK  •  OPERATÖR YOK  •  DOĞRUDAN",10,Color.rgb(153,159,172),true); footer.setGravity(Gravity.CENTER); footer.setLetterSpacing(0.08f); footer.setPadding(dp(10),dp(6),dp(10),dp(12)); root.addView(footer);
    }

    private View peerCard(Peer p) {
        LinearLayout box=row(); box.setPadding(dp(14),dp(14),dp(12),dp(14)); box.setBackground(strokedRound(SURFACE,BORDER,20)); box.setElevation(dp(1));
        box.addView(avatar(p.name,p.connected),new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout details=new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.setPadding(dp(12),0,dp(6),0); details.addView(text(p.name,16,TEXT,true));
        TextView st=text(p.connected?"●  Bağlı ve hazır":"●  Bağlantı kuruluyor",12,p.connected?GREEN:MUTED,false); st.setPadding(0,dp(5),0,0); details.addView(st); box.addView(details,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout actions=row(); Button msg=compactAction("Mesaj",false), call=compactAction("Ara",true); msg.setEnabled(p.connected); call.setEnabled(p.connected); msg.setOnClickListener(v->renderChat(p.endpointId)); call.setOnClickListener(v->placeCall(p.endpointId));
        actions.addView(msg,new LinearLayout.LayoutParams(dp(70),dp(40))); Space gap=new Space(this); actions.addView(gap,new LinearLayout.LayoutParams(dp(6),1)); actions.addView(call,new LinearLayout.LayoutParams(dp(58),dp(40))); box.addView(actions); return box;
    }

    private void renderChat(String endpointId) {
        Peer p=findPeer(endpointId); if(p==null){chatEndpoint=null;renderHome();return;} chatEndpoint=endpointId; prepareLightScreen();
        LinearLayout top=row(); top.setPadding(dp(12),dp(10),dp(12),dp(10)); top.setBackgroundColor(SURFACE);
        Button back=iconButton("‹"); back.setTextSize(28); back.setOnClickListener(v->{chatEndpoint=null;renderHome();}); top.addView(back,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(dp(40),dp(40)); alp.setMargins(dp(4),0,dp(10),0); top.addView(avatar(p.name,p.connected),alp);
        LinearLayout tb=new LinearLayout(this); tb.setOrientation(LinearLayout.VERTICAL); tb.addView(text(p.name,16,TEXT,true)); TextView on=text(p.connected?"●  Yakında":"Bağlantı bekleniyor",11,p.connected?GREEN:MUTED,false); on.setPadding(0,dp(2),0,0); tb.addView(on); top.addView(tb,new LinearLayout.LayoutParams(0,-2,1));
        Button call=iconButton("☎"); call.setTextColor(ACCENT); call.setOnClickListener(v->placeCall(endpointId)); top.addView(call,new LinearLayout.LayoutParams(dp(44),dp(44))); root.addView(top);
        View divider=new View(this); divider.setBackgroundColor(BORDER); root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView scroll=new ScrollView(this); LinearLayout msgs=new LinearLayout(this); msgs.setOrientation(LinearLayout.VERTICAL); msgs.setPadding(dp(14),dp(16),dp(14),dp(16));
        List<String> history=chats.computeIfAbsent(endpointId,k->new ArrayList<>()); if(history.isEmpty()){TextView hint=text("Bu konuşma yalnızca iki cihaz arasında doğrudan aktarılır.",12,MUTED,false); hint.setGravity(Gravity.CENTER); hint.setPadding(dp(18),dp(12),dp(18),dp(12)); hint.setBackground(round(Color.rgb(236,239,246),14)); msgs.addView(hint,spaced(8));}
        for(String line:history){boolean mine=line.startsWith("Ben: "); String clean=mine?line.substring(5):stripSender(line); LinearLayout holder=new LinearLayout(this); holder.setGravity(mine?Gravity.END:Gravity.START); TextView bubble=text(clean,15,mine?Color.WHITE:TEXT,false); bubble.setPadding(dp(14),dp(10),dp(14),dp(10)); bubble.setBackground(round(mine?ACCENT:SURFACE,17)); bubble.setMaxWidth(dp(285)); holder.addView(bubble); msgs.addView(holder,spaced(4));}
        scroll.addView(msgs); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout wrap=new LinearLayout(this); wrap.setPadding(dp(12),dp(8),dp(12),dp(12)); wrap.setBackgroundColor(SURFACE); LinearLayout composer=row();
        EditText input=new EditText(this); input.setSingleLine(true); input.setHint("Mesaj yaz…"); input.setTextColor(TEXT); input.setHintTextColor(Color.rgb(155,161,174)); input.setPadding(dp(16),0,dp(16),0); input.setBackground(strokedRound(Color.rgb(248,249,252),BORDER,18)); composer.addView(input,new LinearLayout.LayoutParams(0,dp(50),1)); Space g=new Space(this); composer.addView(g,new LinearLayout.LayoutParams(dp(8),1));
        Button send=button("Gönder",true); send.setOnClickListener(v->{String m=input.getText().toString().trim(); if(m.isEmpty())return; nearby.sendChat(endpointId,m); chats.get(endpointId).add("Ben: "+m); input.setText(""); renderChat(endpointId);}); composer.addView(send,new LinearLayout.LayoutParams(dp(88),dp(50))); wrap.addView(composer); root.addView(wrap);
    }

    private void placeCall(String endpointId) {
        if(!nearby.isConnected(endpointId)){Toast.makeText(this,"Kullanıcı henüz bağlı değil",Toast.LENGTH_SHORT).show();return;}
        callEndpoint=endpointId; callActive=false; ringback.start(); nearby.sendControl(endpointId,"CALL_INVITE",""); renderCall();
    }

    private void renderCall() {
        root.removeAllViews(); root.setGravity(Gravity.CENTER); root.setBackgroundColor(DARK); getWindow().setStatusBarColor(DARK); getWindow().setNavigationBarColor(DARK); getWindow().getDecorView().setSystemUiVisibility(0);
        Peer p=findPeer(callEndpoint); LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setGravity(Gravity.CENTER_HORIZONTAL); screen.setPadding(dp(28),dp(34),dp(28),dp(34));
        TextView label=text("İLET",11,Color.rgb(148,153,177),true); label.setLetterSpacing(0.18f); screen.addView(label); TextView av=avatarDark(p==null?"?":p.name); LinearLayout.LayoutParams al=new LinearLayout.LayoutParams(dp(108),dp(108)); al.setMargins(0,dp(44),0,dp(22)); screen.addView(av,al);
        TextView n=text(p==null?"Yakındaki kullanıcı":p.name,27,Color.WHITE,true); n.setGravity(Gravity.CENTER); screen.addView(n); TextView st=text(callActive?"●  Görüşme aktif":"Aranıyor…",14,callActive?Color.rgb(101,231,170):Color.rgb(177,182,203),true); st.setGravity(Gravity.CENTER); st.setPadding(0,dp(10),0,dp(52)); screen.addView(st);
        Button end=button("Aramayı bitir",false); end.setTextColor(Color.WHITE); end.setBackground(round(RED,26)); end.setOnClickListener(v->stopCall(true)); screen.addView(end,new LinearLayout.LayoutParams(dp(190),dp(56))); root.addView(screen,new LinearLayout.LayoutParams(-1,-2));
    }

    private void incomingCall(String endpointId) {
        if(callEndpoint!=null){nearby.sendControl(endpointId,"CALL_REJECT","busy");return;} Peer p=findPeer(endpointId);
        new AlertDialog.Builder(this).setTitle("Gelen arama").setMessage((p==null?"Yakındaki kullanıcı":p.name)+" sizi arıyor.")
                .setNegativeButton("Reddet",(d,w)->nearby.sendControl(endpointId,"CALL_REJECT",""))
                .setPositiveButton("Yanıtla",(d,w)->{callEndpoint=endpointId;callActive=true;nearby.sendControl(endpointId,"CALL_ACCEPT","");if(!startAudio(endpointId)){nearby.sendControl(endpointId,"CALL_END","audio");stopCall(false);}else renderCall();})
                .setCancelable(false).show();
    }
    private boolean startAudio(String endpointId){return audio.start((pcm,len)->nearby.sendAudio(endpointId,pcm,len));}
    private void stopCall(boolean notify){String ep=callEndpoint;if(notify&&ep!=null&&nearby.isConnected(ep))nearby.sendControl(ep,"CALL_END","");ringback.stop();nearby.stopIncomingAlert();audio.stop();callEndpoint=null;callActive=false;if(root!=null)renderHome();}

    @Override public void onPeersChanged(List<Peer> value){runOnUiThread(()->{peers=value;if(callEndpoint!=null&&!nearby.isConnected(callEndpoint)){stopCall(false);Toast.makeText(this,"Bağlantı kesildi",Toast.LENGTH_SHORT).show();}else renderCurrent();});}
    @Override public void onChatMessage(String endpointId,String message){runOnUiThread(()->{Peer p=findPeer(endpointId);chats.computeIfAbsent(endpointId,k->new ArrayList<>()).add((p==null?"Kişi":p.name)+": "+message);if(endpointId.equals(chatEndpoint)&&callEndpoint==null)renderChat(endpointId);});}
    @Override public void onControl(String endpointId,String type,String value){runOnUiThread(()->{switch(type){case"CALL_INVITE":incomingCall(endpointId);break;case"CALL_ACCEPT":ringback.stop();if(endpointId.equals(callEndpoint)&&!callActive){callActive=true;if(!startAudio(endpointId))stopCall(true);else renderCall();}break;case"CALL_REJECT":ringback.stop();if(endpointId.equals(callEndpoint)){Toast.makeText(this,"Arama reddedildi",Toast.LENGTH_SHORT).show();stopCall(false);}break;case"CALL_END":ringback.stop();if(endpointId.equals(callEndpoint))stopCall(false);break;default:break;}});}
    @Override public void onAudio(String endpointId,byte[] pcm){if(endpointId.equals(callEndpoint)&&callActive)audio.play(pcm);}
    @Override public void onStatus(String value){runOnUiThread(()->{status=value;if(chatEndpoint==null&&callEndpoint==null)renderHome();});}

    private void editName(){EditText input=new EditText(this);input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);input.setText(nearby.getDisplayName());input.setSelection(input.length());new AlertDialog.Builder(this).setTitle("Görünen ad").setMessage("Yakındaki kullanıcılar sizi bu adla görecek.").setView(input).setNegativeButton("Vazgeç",null).setPositiveButton("Kaydet",(d,w)->{nearby.setDisplayName(input.getText().toString());renderHome();}).show();}
    private Peer findPeer(String endpointId){if(endpointId==null)return null;for(Peer p:peers)if(endpointId.equals(p.endpointId))return p;return null;}
    private String stripSender(String line){int i=line.indexOf(": ");return i>=0?line.substring(i+2):line;}
    private String initials(String name){String c=name==null?"":name.trim();if(c.isEmpty())return"?";String[]p=c.split("\\s+");if(p.length==1)return p[0].substring(0,1).toUpperCase(Locale.ROOT);return(p[0].substring(0,1)+p[p.length-1].substring(0,1)).toUpperCase(Locale.ROOT);}
    private TextView avatar(String name,boolean connected){TextView a=text(initials(name),16,connected?ACCENT_DARK:MUTED,true);a.setGravity(Gravity.CENTER);a.setBackground(round(connected?ACCENT_SOFT:Color.rgb(239,241,245),30));return a;}
    private TextView avatarDark(String name){TextView a=text(initials(name),32,Color.WHITE,true);a.setGravity(Gravity.CENTER);GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(112,114,255),Color.rgb(76,77,205)});bg.setShape(GradientDrawable.OVAL);a.setBackground(bg);return a;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams spaced(int n){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(n),0,dp(n));return p;}
    private Button button(String label,boolean primary){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextColor(primary?Color.WHITE:TEXT);b.setPadding(dp(12),0,dp(12),0);b.setMinHeight(0);b.setMinWidth(0);b.setBackground(round(primary?ACCENT:Color.rgb(238,240,245),16));return b;}
    private Button compactAction(String label,boolean primary){Button b=button(label,primary);b.setTextSize(12);return b;}
    private Button pillButton(String label){Button b=button(label,false);b.setTextSize(14);b.setBackground(strokedRound(SURFACE,BORDER,30));return b;}
    private Button iconButton(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(20);b.setTextColor(TEXT);b.setGravity(Gravity.CENTER);b.setPadding(0,0,0,0);b.setMinHeight(0);b.setMinWidth(0);b.setBackground(round(Color.TRANSPARENT,22));return b;}
    private TextView text(String value,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(value);v.setTextSize(sp);v.setTextColor(color);if(bold)v.setTypeface(Typeface.create("sans",Typeface.BOLD));return v;}
    private GradientDrawable round(int color,int radiusDp){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radiusDp));return d;}
    private GradientDrawable strokedRound(int color,int strokeColor,int radiusDp){GradientDrawable d=round(color,radiusDp);d.setStroke(dp(1),strokeColor);return d;}
    private GradientDrawable gradientCard(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(101,102,236),Color.rgb(68,69,197)});d.setCornerRadius(dp(24));return d;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
