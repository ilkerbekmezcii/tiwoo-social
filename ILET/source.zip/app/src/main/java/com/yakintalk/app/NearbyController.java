package com.yakintalk.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public final class NearbyController {
    public interface Listener {
        void onPeersChanged(List<Peer> peers);
        void onChatMessage(String endpointId, String message);
        void onControl(String endpointId, String type, String value);
        void onAudio(String endpointId, byte[] pcm);
        void onStatus(String status);
    }

    private static final String TAG = "YakinTalkNearby";
    private static final String SERVICE_ID = "com.yakintalk.app.nearby.v1";
    private static final Strategy STRATEGY = Strategy.P2P_CLUSTER;
    private static final byte PACKET_CONTROL = 1;
    private static final byte PACKET_AUDIO = 2;

    private final Context context;
    private final Listener listener;
    private final ConnectionsClient client;
    private final Map<String, Peer> peers = new LinkedHashMap<>();
    private final Set<String> connectionRequests = new HashSet<>();
    private final String localStableId;
    private String displayName;
    private boolean running;

    public NearbyController(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        this.client = Nearby.getConnectionsClient(context);
        SharedPreferences prefs = context.getSharedPreferences("identity", Context.MODE_PRIVATE);
        String id = prefs.getString("peer_id", null);
        if (id == null) {
            byte[] random = new byte[6];
            new SecureRandom().nextBytes(random);
            StringBuilder sb = new StringBuilder();
            for (byte b : random) sb.append(String.format(Locale.US, "%02x", b & 0xff));
            id = sb.toString();
            prefs.edit().putString("peer_id", id).apply();
        }
        localStableId = id;
        String oldAutomaticName = "Kullanıcı " + id.substring(0, 4).toUpperCase(Locale.ROOT);
        String savedName = prefs.getString("display_name", null);
        if (savedName == null || oldAutomaticName.equals(savedName)) {
            String deviceName = null;
            try {
                deviceName = Settings.Global.getString(
                        context.getContentResolver(), Settings.Global.DEVICE_NAME);
            } catch (Exception ignored) {
            }
            if (deviceName == null || deviceName.trim().isEmpty()) deviceName = Build.MODEL;
            if (deviceName == null || deviceName.trim().isEmpty()) deviceName = "Android";
            deviceName = deviceName.trim();
            if (deviceName.length() > 18) deviceName = deviceName.substring(0, 18);
            displayName = deviceName;
            prefs.edit().putString("display_name", displayName).apply();
        } else {
            displayName = savedName;
        }
    }

    public String getLocalStableId() {
        return localStableId;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String name) {
        String clean = name == null ? "" : name.trim();
        if (clean.isEmpty()) return;
        if (clean.length() > 18) clean = clean.substring(0, 18);
        displayName = clean;
        context.getSharedPreferences("identity", Context.MODE_PRIVATE)
                .edit().putString("display_name", clean).apply();
        if (running) {
            stop();
            start();
        }
    }

    public void start() {
        if (running) return;
        running = true;
        String endpointName = encodeEndpointName(localStableId, displayName);
        AdvertisingOptions advertising = new AdvertisingOptions.Builder().setStrategy(STRATEGY).build();
        DiscoveryOptions discovery = new DiscoveryOptions.Builder().setStrategy(STRATEGY).build();

        client.startAdvertising(endpointName, SERVICE_ID, lifecycleCallback, advertising)
                .addOnSuccessListener(unused -> listener.onStatus("Yakındaki kullanıcılara görünür"))
                .addOnFailureListener(e -> {
                    Log.w(TAG, "Advertising failed", e);
                    listener.onStatus("Yayın başlatılamadı: " + shortError(e));
                });

        client.startDiscovery(SERVICE_ID, discoveryCallback, discovery)
                .addOnSuccessListener(unused -> listener.onStatus("Yakındaki kullanıcılar aranıyor"))
                .addOnFailureListener(e -> {
                    Log.w(TAG, "Discovery failed", e);
                    listener.onStatus("Tarama başlatılamadı: " + shortError(e));
                });
    }

    public void stop() {
        if (!running) return;
        running = false;
        try { client.stopAdvertising(); } catch (Exception ignored) {}
        try { client.stopDiscovery(); } catch (Exception ignored) {}
        try { client.stopAllEndpoints(); } catch (Exception ignored) {}
        connectionRequests.clear();
        for (Peer peer : peers.values()) peer.connected = false;
        publishPeers();
    }

    public List<Peer> getPeers() {
        return snapshotPeers();
    }

    public boolean isConnected(String endpointId) {
        Peer p = peers.get(endpointId);
        return p != null && p.connected;
    }

    public void sendChat(String endpointId, String text) {
        sendControl(endpointId, "CHAT", text);
    }

    public void sendControl(String endpointId, String type, String value) {
        if (!isConnected(endpointId)) {
            listener.onStatus("Kullanıcı henüz bağlı değil");
            return;
        }
        String body = type + "|" + (value == null ? "" : value);
        byte[] text = body.getBytes(StandardCharsets.UTF_8);
        byte[] packet = new byte[text.length + 1];
        packet[0] = PACKET_CONTROL;
        System.arraycopy(text, 0, packet, 1, text.length);
        client.sendPayload(endpointId, Payload.fromBytes(packet))
                .addOnFailureListener(e -> listener.onStatus("Gönderilemedi: " + shortError(e)));
    }

    public void sendAudio(String endpointId, byte[] pcm, int length) {
        if (!isConnected(endpointId) || pcm == null || length <= 0) return;
        byte[] packet = new byte[length + 1];
        packet[0] = PACKET_AUDIO;
        System.arraycopy(pcm, 0, packet, 1, length);
        client.sendPayload(endpointId, Payload.fromBytes(packet));
    }

    private final EndpointDiscoveryCallback discoveryCallback = new EndpointDiscoveryCallback() {
        @Override
        public void onEndpointFound(String endpointId, DiscoveredEndpointInfo info) {
            EndpointName parsed = decodeEndpointName(info.getEndpointName());
            if (parsed == null || localStableId.equals(parsed.stableId)) return;

            Peer peer = peers.get(endpointId);
            if (peer == null) {
                peer = new Peer(endpointId, parsed.stableId, parsed.name);
                peers.put(endpointId, peer);
            } else {
                peer.stableId = parsed.stableId;
                peer.name = parsed.name;
                peer.discovered = true;
                peer.lastSeenMs = System.currentTimeMillis();
            }
            publishPeers();

            // Deterministic side selection prevents both phones from initiating the same link.
            if (localStableId.compareTo(parsed.stableId) < 0) requestConnection(peer);
        }

        @Override
        public void onEndpointLost(String endpointId) {
            Peer peer = peers.get(endpointId);
            if (peer != null) {
                peer.discovered = false;
                peer.lastSeenMs = System.currentTimeMillis();
                if (!peer.connected) peers.remove(endpointId);
                publishPeers();
            }
            connectionRequests.remove(endpointId);
        }
    };

    private void requestConnection(Peer peer) {
        if (peer.connected || connectionRequests.contains(peer.endpointId)) return;
        connectionRequests.add(peer.endpointId);
        client.requestConnection(encodeEndpointName(localStableId, displayName), peer.endpointId, lifecycleCallback)
                .addOnFailureListener(e -> {
                    connectionRequests.remove(peer.endpointId);
                    Log.w(TAG, "Connection request failed", e);
                });
    }

    private final ConnectionLifecycleCallback lifecycleCallback = new ConnectionLifecycleCallback() {
        @Override
        public void onConnectionInitiated(String endpointId, ConnectionInfo info) {
            EndpointName parsed = decodeEndpointName(info.getEndpointName());
            Peer peer = peers.get(endpointId);
            if (peer == null) {
                String sid = parsed != null ? parsed.stableId : endpointId;
                String name = parsed != null ? parsed.name : "Yakındaki kullanıcı";
                peer = new Peer(endpointId, sid, name);
                peers.put(endpointId, peer);
            }
            // Product requirement: connection is app-level automatic; no pairing/PIN UI.
            client.acceptConnection(endpointId, payloadCallback)
                    .addOnFailureListener(e -> listener.onStatus("Bağlantı kabul edilemedi: " + shortError(e)));
            publishPeers();
        }

        @Override
        public void onConnectionResult(String endpointId, ConnectionResolution resolution) {
            connectionRequests.remove(endpointId);
            Peer peer = peers.get(endpointId);
            if (resolution.getStatus().isSuccess()) {
                if (peer != null) {
                    peer.connected = true;
                    peer.discovered = true;
                    peer.lastSeenMs = System.currentTimeMillis();
                }
                listener.onStatus("Bağlantı hazır");
            } else {
                if (peer != null) peer.connected = false;
                listener.onStatus("Bağlantı kurulamadı");
            }
            publishPeers();
        }

        @Override
        public void onDisconnected(String endpointId) {
            connectionRequests.remove(endpointId);
            Peer peer = peers.get(endpointId);
            if (peer != null) {
                peer.connected = false;
                if (!peer.discovered) peers.remove(endpointId);
            }
            publishPeers();
        }
    };

    private final PayloadCallback payloadCallback = new PayloadCallback() {
        @Override
        public void onPayloadReceived(String endpointId, Payload payload) {
            if (payload.getType() != Payload.Type.BYTES || payload.asBytes() == null) return;
            byte[] bytes = payload.asBytes();
            if (bytes.length < 1) return;
            if (bytes[0] == PACKET_AUDIO) {
                byte[] pcm = new byte[bytes.length - 1];
                System.arraycopy(bytes, 1, pcm, 0, pcm.length);
                listener.onAudio(endpointId, pcm);
                return;
            }
            if (bytes[0] == PACKET_CONTROL) {
                String value = new String(bytes, 1, bytes.length - 1, StandardCharsets.UTF_8);
                int split = value.indexOf('|');
                String type = split >= 0 ? value.substring(0, split) : value;
                String body = split >= 0 ? value.substring(split + 1) : "";
                if ("CHAT".equals(type)) listener.onChatMessage(endpointId, body);
                else listener.onControl(endpointId, type, body);
            }
        }

        @Override
        public void onPayloadTransferUpdate(String endpointId, PayloadTransferUpdate update) {
            // BYTES payloads are delivered atomically; no progress UI needed for this MVP.
        }
    };

    private void publishPeers() {
        listener.onPeersChanged(snapshotPeers());
    }

    private List<Peer> snapshotPeers() {
        List<Peer> out = new ArrayList<>();
        for (Peer p : peers.values()) {
            if (p.discovered || p.connected) out.add(p);
        }
        Collections.sort(out, Comparator
                .comparing((Peer p) -> !p.connected)
                .thenComparing(p -> p.name.toLowerCase(Locale.ROOT)));
        return out;
    }

    private static String encodeEndpointName(String stableId, String displayName) {
        String clean = displayName.replace('|', ' ').trim();
        if (clean.length() > 18) clean = clean.substring(0, 18);
        return stableId + "|" + clean;
    }

    private static EndpointName decodeEndpointName(String encoded) {
        if (encoded == null) return null;
        int split = encoded.indexOf('|');
        if (split <= 0 || split >= encoded.length() - 1) return null;
        return new EndpointName(encoded.substring(0, split), encoded.substring(split + 1));
    }

    private static String shortError(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return e.getClass().getSimpleName();
        return m.length() > 80 ? m.substring(0, 80) : m;
    }

    private static final class EndpointName {
        final String stableId;
        final String name;
        EndpointName(String stableId, String name) {
            this.stableId = stableId;
            this.name = name;
        }
    }
}
