package com.yakintalk.app;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;

public final class IletRuntime implements NearbyController.Listener {
    private static volatile IletRuntime instance;
    public static IletRuntime get(Context context) {
        if (instance == null) {
            synchronized (IletRuntime.class) {
                if (instance == null) instance = new IletRuntime(context.getApplicationContext());
            }
        }
        return instance;
    }

    private static final class PendingChat {
        final String endpointId, message;
        PendingChat(String endpointId, String message) { this.endpointId = endpointId; this.message = message; }
    }
    private static final class PendingControl {
        final String endpointId, type, value;
        PendingControl(String endpointId, String type, String value) { this.endpointId = endpointId; this.type = type; this.value = value; }
    }

    private final NearbyController nearby;
    private final IletNotifications notifications;
    private final List<PendingChat> pendingChats = new ArrayList<>();
    private final List<PendingControl> pendingControls = new ArrayList<>();
    private NearbyController.Listener uiListener;
    private String pendingIncomingCallEndpoint;
    private String lastStatus = "Hazırlanıyor";

    private IletRuntime(Context context) {
        nearby = new NearbyController(context, this);
        notifications = IletNotifications.get(context);
    }

    public synchronized void attachUi(NearbyController.Listener listener) {
        uiListener = listener;
        listener.onPeersChanged(nearby.getPeers());
        listener.onStatus(lastStatus);
        if (!pendingChats.isEmpty()) {
            List<PendingChat> copy = new ArrayList<>(pendingChats); pendingChats.clear();
            for (PendingChat chat : copy) listener.onChatMessage(chat.endpointId, chat.message);
        }
        if (pendingIncomingCallEndpoint != null) listener.onControl(pendingIncomingCallEndpoint, "CALL_INVITE", "");
        if (!pendingControls.isEmpty()) {
            List<PendingControl> copy = new ArrayList<>(pendingControls); pendingControls.clear();
            for (PendingControl c : copy) listener.onControl(c.endpointId, c.type, c.value);
        }
    }
    public synchronized void detachUi(NearbyController.Listener listener) { if (uiListener == listener) uiListener = null; }

    public void start() { nearby.start(); }
    public void stop() { nearby.stop(); }
    public List<Peer> getPeers() { return nearby.getPeers(); }
    public boolean isConnected(String endpointId) { return nearby.isConnected(endpointId); }
    public String getDisplayName() { return nearby.getDisplayName(); }
    public String getLocalStableId() { return nearby.getLocalStableId(); }
    public void setDisplayName(String name) { nearby.setDisplayName(name); }
    public void sendChat(String endpointId, String text) { nearby.sendChat(endpointId, text); }
    public void sendAudio(String endpointId, byte[] pcm, int length) { nearby.sendAudio(endpointId, pcm, length); }

    public synchronized void sendControl(String endpointId, String type, String value) {
        if ("CALL_ACCEPT".equals(type) || "CALL_REJECT".equals(type) || "CALL_END".equals(type)) {
            if (endpointId != null && endpointId.equals(pendingIncomingCallEndpoint)) pendingIncomingCallEndpoint = null;
            notifications.stopIncomingCall();
        }
        nearby.sendControl(endpointId, type, value);
    }
    public synchronized void stopIncomingAlert() { pendingIncomingCallEndpoint = null; notifications.stopIncomingCall(); }

    @Override public synchronized void onPeersChanged(List<Peer> peers) { if (uiListener != null) uiListener.onPeersChanged(peers); }
    @Override public synchronized void onChatMessage(String endpointId, String message) {
        notifications.showMessage(endpointId, peerName(endpointId));
        if (uiListener != null) uiListener.onChatMessage(endpointId, message);
        else { if (pendingChats.size() >= 100) pendingChats.remove(0); pendingChats.add(new PendingChat(endpointId, message)); }
    }
    @Override public synchronized void onControl(String endpointId, String type, String value) {
        if ("CALL_INVITE".equals(type)) {
            pendingIncomingCallEndpoint = endpointId;
            notifications.startIncomingCall(peerName(endpointId));
            if (uiListener != null) uiListener.onControl(endpointId, type, value);
            return;
        }
        if ("CALL_REJECT".equals(type) || "CALL_END".equals(type)) {
            if (endpointId != null && endpointId.equals(pendingIncomingCallEndpoint)) {
                pendingIncomingCallEndpoint = null; notifications.stopIncomingCall();
            }
        }
        if (uiListener != null) uiListener.onControl(endpointId, type, value);
        else { if (pendingControls.size() >= 30) pendingControls.remove(0); pendingControls.add(new PendingControl(endpointId, type, value)); }
    }
    @Override public synchronized void onAudio(String endpointId, byte[] pcm) { if (uiListener != null) uiListener.onAudio(endpointId, pcm); }
    @Override public synchronized void onStatus(String status) { lastStatus = status; if (uiListener != null) uiListener.onStatus(status); }

    private String peerName(String endpointId) {
        for (Peer peer : nearby.getPeers()) if (peer.endpointId.equals(endpointId)) return peer.name;
        return "Yakındaki kullanıcı";
    }
}
