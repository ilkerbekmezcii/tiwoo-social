package com.yakintalk.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public final class IletNotifications {
    private static final String CH_SERVICE = "ilet_background";
    private static final String CH_MESSAGE = "ilet_messages";
    private static final String CH_CALL = "ilet_calls";
    private static final int CALL_ID = 4200;
    private static volatile IletNotifications instance;

    public static IletNotifications get(Context context) {
        if (instance == null) {
            synchronized (IletNotifications.class) {
                if (instance == null) instance = new IletNotifications(context.getApplicationContext());
            }
        }
        return instance;
    }

    private final Context context;
    private final NotificationManager manager;
    private Ringtone ringtone;
    private MediaPlayer legacyRingtone;

    private IletNotifications(Context context) {
        this.context = context;
        this.manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannels();
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;

        NotificationChannel service = new NotificationChannel(
                CH_SERVICE, "İLET arka plan bağlantısı", NotificationManager.IMPORTANCE_MIN);
        service.setDescription("Yakındaki İLET kullanıcılarını arka planda bulur.");
        service.setSound(null, null);
        service.setShowBadge(false);
        manager.createNotificationChannel(service);

        Uri messageSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        AudioAttributes messageAttrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION).build();
        NotificationChannel messages = new NotificationChannel(
                CH_MESSAGE, "Mesajlar", NotificationManager.IMPORTANCE_HIGH);
        messages.setDescription("Yeni İLET mesajları.");
        messages.enableVibration(true);
        messages.setSound(messageSound, messageAttrs);
        manager.createNotificationChannel(messages);

        NotificationChannel calls = new NotificationChannel(
                CH_CALL, "Aramalar", NotificationManager.IMPORTANCE_HIGH);
        calls.setDescription("Gelen İLET aramaları.");
        calls.enableVibration(true);
        calls.setVibrationPattern(new long[]{0, 500, 500, 500, 500, 900});
        calls.setSound(null, null);
        manager.createNotificationChannel(calls);
    }

    public Notification buildServiceNotification() {
        return builder(CH_SERVICE)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("İLET")
                .setContentText("Yakındaki kullanıcılarla bağlantı hazır")
                .setContentIntent(mainIntent())
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setPriority(Notification.PRIORITY_MIN)
                .setShowWhen(false)
                .build();
    }

    public void showMessage(String endpointId, String senderName) {
        Notification notification = builder(CH_MESSAGE)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(senderName)
                .setContentText("Yeni mesaj")
                .setContentIntent(mainIntent())
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Build.VERSION.SDK_INT < 26
                        ? Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE : 0)
                .build();
        manager.notify(5000 + Math.abs(endpointId.hashCode() % 1000), notification);
    }

    public synchronized void startIncomingCall(String callerName) {
        stopIncomingCall();
        Notification notification = builder(CH_CALL)
                .setSmallIcon(android.R.drawable.stat_sys_phone_call)
                .setContentTitle("Gelen İLET araması")
                .setContentText(callerName + " sizi arıyor")
                .setContentIntent(mainIntent())
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(Notification.PRIORITY_MAX)
                .setDefaults(Build.VERSION.SDK_INT < 26 ? Notification.DEFAULT_VIBRATE : 0)
                .build();
        manager.notify(CALL_ID, notification);

        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                ringtone = RingtoneManager.getRingtone(context, uri);
                if (ringtone != null) {
                    ringtone.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());
                    ringtone.setLooping(true);
                    ringtone.play();
                }
            } else {
                legacyRingtone = new MediaPlayer();
                legacyRingtone.setDataSource(context, uri);
                legacyRingtone.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());
                legacyRingtone.setLooping(true);
                legacyRingtone.prepare();
                legacyRingtone.start();
            }
        } catch (Exception ignored) { }
    }

    public synchronized void stopIncomingCall() {
        manager.cancel(CALL_ID);
        if (ringtone != null) {
            try { ringtone.stop(); } catch (Exception ignored) { }
            ringtone = null;
        }
        if (legacyRingtone != null) {
            try { legacyRingtone.stop(); } catch (Exception ignored) { }
            try { legacyRingtone.release(); } catch (Exception ignored) { }
            legacyRingtone = null;
        }
    }

    private Notification.Builder builder(String channel) {
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(context, channel);
        return new Notification.Builder(context);
    }

    private PendingIntent mainIntent() {
        Intent intent = new Intent(context, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, 77, intent, flags);
    }
}
