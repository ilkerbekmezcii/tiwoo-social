package com.yakintalk.app;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

public final class IletService extends Service {
    public static final int FOREGROUND_ID = 4100;

    public static void start(Context context) {
        Intent intent = new Intent(context, IletService.class);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent);
        else context.startService(intent);
    }

    @Override public void onCreate() {
        super.onCreate();
        Notification notification = IletNotifications.get(this).buildServiceNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(FOREGROUND_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        } else {
            startForeground(FOREGROUND_ID, notification);
        }
        IletRuntime.get(this).start();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        IletRuntime.get(this).start();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        IletRuntime.get(this).stop();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
