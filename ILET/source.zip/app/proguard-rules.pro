# YakinTalk currently uses no reflection-based app code that needs custom keep rules.
