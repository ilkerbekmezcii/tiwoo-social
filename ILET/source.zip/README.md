# YakınTalk

YakınTalk is an offline, operator-free Android messenger/calling MVP built on Google Nearby Connections.

## What it does

- Automatically advertises and discovers nearby YakınTalk users.
- Automatically establishes app-to-app Nearby Connections; there is no Bluetooth pairing screen, Wi-Fi network selection, PIN, or hotspot setup in the app flow.
- Shows discovered/connected nearby users.
- Sends text messages directly between nearby Android phones.
- Supports one-to-one live voice calls with incoming call accept/reject.
- Does not require a phone number, SIM card, mobile operator, backend, or Internet connection for nearby communication.
- Uses a pseudonymous local peer identity instead of the phone number or Android device ID.

## Important Android limitation

The OS still requires runtime permission approval for nearby-device access and microphone access. Some devices/OEM versions may also surface system resolution UI if Google Play services needs a radio setting changed. An ordinary app cannot legally/technically bypass those system controls.

## Build

Requirements:

- JDK 17+
- Android SDK Platform 36
- Android Build Tools
- Gradle / Android Gradle Plugin 8.13

Build debug APK:

```bash
./gradlew assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Transport

The app uses `com.google.android.gms:play-services-nearby:19.5.0` and the `P2P_CLUSTER` strategy. Nearby Connections can use Bluetooth/BLE/Wi-Fi under the hood and does not require the phones to be on the same Internet-connected network.

## Privacy notes

This MVP intentionally does not use a backend or phone numbers and does not persist chat history. Nearby Connections protects its transport, but this MVP does **not yet implement a separate application-layer Signal-style identity protocol**. Before production use, add persistent cryptographic identities, authenticated key exchange / safety-number verification, forward secrecy, and encrypted local persistence if chat history is added.

## Test procedure

1. Install the debug APK on two Android phones with Google Play services.
2. Open YakınTalk on both.
3. Grant Nearby Devices and microphone permissions.
4. Keep Wi-Fi and Bluetooth available.
5. Each phone should appear in the other phone's nearby list and auto-connect.
6. Tap a peer to open chat; send a text.
7. Tap **Ara** to place a call; accept it on the other device.
